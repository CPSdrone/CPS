Arduino-KalmanFilter
====================

This library is prepared for IMU calculations

See examples: http://www.jarzebski.pl/arduino/rozwiazania-i-algorytmy/odczyty-pitch-roll-oraz-filtr-kalmana.html

I need your help
----------------

July 31, 2017

In the near future I plan to refactoring the libraries. The main goal is to improve code quality, new features and add support for different versions of Arduino boards like Uno, Mega and Zero.

For this purpose I need to buy modules, Arduino Boards and lot of beer. 

If you want to support the further and long-term development of libraries, please help.

You can do this by transferring any amount to my PayPal account: paypal@jarzebski.pl

Thanks!
