# MAX7456
A library for interfacing with MAX7456 OSD chip originally created by people at http://theboredengineers.com/2012/12/a-max7456-library-for-arduino/.

This library should be compatible with Arduino IDE 1.6.6.
