# Project Notes
Some Updates in here… (placeholder for now)

# Update Aug. 10.
After some field testing I figured out that the MAX Chip used on the MinimOSD micro is not suited for this aplication. 
The MAX requires a very stable video signal to work. In my tests the OSD gets unstable at 75% RSSI and disappears completely at 50% showing only black or grey screen (dangerous). I have searched for days for a solution but I fear I have to look into other hardware options like the LM1881 chip used in the DIYOSD project. 

https://www.youtube.com/embed/iRrj66cfb9g
